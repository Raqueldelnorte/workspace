// src/components/UsersList.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

function UsersList() {
  console.log("UsersList component function is being called!");
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  // Función para manejar el cierre de sesión
  const handleLogout = () => {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('auth'); // Si lo utilizaste
    navigate('/');
  };

  useEffect(() => {
    console.log("UsersList useEffect is running!");
    const fetchUsers = async () => {
      console.log("fetchUsers function is being called!");
      setLoading(true);
      setError(null);
      try {
        console.log("Before calling api.getAllUsers()");
        const data = await api.getAllUsers();
        console.log("After calling api.getAllUsers(), response data:", data);
        // Agregamos un log para ver los datos de los usuarios
        console.log('Datos de usuarios:', data);
        setUsers(data);
      } catch (error) {
        setError(error.message || 'Error al cargar usuarios');
        console.error("Error fetching users:", error);
      } finally {
        setLoading(false);
        console.log("fetchUsers function finally block executed");
      }
    };

    fetchUsers();
    console.log("After calling fetchUsers() inside useEffect");
  }, []);

  if (loading) {
    return <p>Cargando usuarios...</p>;
  }

  if (error) {
    return <p style={{ color: 'red' }}>Error: {error}</p>;
  }

  return (
    <div>
      <h2>Lista de Usuarios</h2>
      <button onClick={handleLogout}>Cerrar Sesión</button>
      <table border="1" cellPadding="5" cellSpacing="0">
        <thead>
          <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Activo</th>
            <th>Tipo</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.email || 'Sin email'}</td>
              <td>{user.active ? 'Sí' : 'No'}</td>
              <td>{user.type || 'Sin tipo'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default UsersList;

